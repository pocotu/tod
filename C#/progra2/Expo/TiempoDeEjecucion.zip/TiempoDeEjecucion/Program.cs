﻿using System;

namespace Busqueda
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] lista = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };
            int valorBuscado = 14;

            Comparacion comparacion = new Comparacion(lista, valorBuscado);
            comparacion.RealizarComparacion();
        }
    }
}

/*
using System;

namespace B_Secuencial
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] lista = { 4, 7, 2, 1, 5, 9, 8, 3, 6 };
            int valorBuscado = 9;

            int posicion = Busqueda.BusquedaSecuencial(lista, valorBuscado);

            Busqueda.ImprimirResultado(valorBuscado, posicion);
        }
    }
}
*/