0 . Do not use it for Business purpose.
1 . You have to installed Dlib, face_reconition, opencv.