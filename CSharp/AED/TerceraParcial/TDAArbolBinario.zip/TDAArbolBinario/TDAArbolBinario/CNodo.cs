﻿using System;
using System.Collections.Generic;

namespace appABB
{
    internal class CNodo
    {
        // Atributos
        public int valor;
        public CNodo hijoIzquierdo;
        public CNodo hijoDerecho;
    }
}
