using System;

namespace AppPlaya
{
    public class Vehiculo
    {
        public string Nombre { get; set; }

        public Vehiculo(string nombre)
        {
            Nombre = nombre;
        }
    }
}
